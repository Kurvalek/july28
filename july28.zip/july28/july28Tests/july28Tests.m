//
//  july28Tests.m
//  july28Tests
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "july28Tests.h"

@implementation july28Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in july28Tests");
}

@end
