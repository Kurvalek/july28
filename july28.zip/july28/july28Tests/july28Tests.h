//
//  july28Tests.h
//  july28Tests
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface july28Tests : SenTestCase

@end
