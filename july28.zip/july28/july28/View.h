//
//  View.h
//  july28
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;

@interface View : UIView {
    ViewController *viewController;
}

-(id) initWithFrame: (CGRect) frame controller: (ViewController *) c;
@end

