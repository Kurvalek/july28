//
//  ViewController.h
//  july28
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface ViewController: UIViewController {
	NSString *text;
}

- (id) initWithText: (NSString *) t
			  title: (NSString *) title
			  image: (UIImage *) image
			  badge: (NSString *) badge;

@property (nonatomic, copy) IBOutlet NSString *text;
@end
