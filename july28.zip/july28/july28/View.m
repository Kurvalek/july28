//
//  View.m
//  july28
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "View.h"
#import "ViewController.h"

@implementation View

- (id)initWithFrame:(CGRect)frame controller: (ViewController *) c{
    
    self = [super initWithFrame:frame];
    if (self) {
		
		viewController = c;		
		
		if (viewController.title == @"Coffee"){
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"coffee2.jpg"]];
		} else if (viewController.title == @"Pizza") {
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"pizza2.jpg"]];			
		} else if (viewController.title == @"Burgers") {
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"burger2.jpg"]];			
		} else if (viewController.title == @"Desserts") {
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"desserts2.jpg"]];		
        } else if (viewController.title == @"Cocktails") {
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"cocktails2.jpg"]];	
		} else {
			self.backgroundColor = [UIColor blackColor];
		}
        
		    }
    return self;
}



// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing codeCGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 1.0, 1.0, 1.0, 1.0);
	UIFont *f = [UIFont fontWithName: @"Courier" size: 27];
	NSString *s = viewController.text;
	[s drawAtPoint: CGPointMake(120,120) withFont: f];
}


- (void)dealloc {
    [super dealloc];
}




@end
