//
//  july28AppDelegate.h
//  july28
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface july28AppDelegate : NSObject <UIApplicationDelegate> {
UITabBarController *tabBarController;
UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
