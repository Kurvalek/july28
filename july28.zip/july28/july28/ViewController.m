//
//  ViewController.m
//  july28
//
//  Created by Kathleen Urvalek on 8/10/11.
//  Copyright 2011 Self. All rights reserved.
//

#import "ViewController.h"
#import "View.h"

@implementation ViewController
@synthesize text;

-(id) initWithText: (NSString *) t
			 title: (NSString *) title
			 image: (UIImage *) image
			 badge: (NSString *) badge{
	
	if((self = [super initWithNibName: nil bundle: nil]) !=nil){
		self.title = title;
		self.tabBarItem.image = image;
		self.tabBarItem.badgeValue = badge;
		self.text = t; //text = [t copy];
	}
	
	return self;
}

- (void)loadView {
	CGRect f = [UIScreen mainScreen].applicationFrame;
	self.view = [[View alloc] initWithFrame: f controller: self];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
/*
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)dealloc {
	[self.view release];
	[text release]; //because was created with copy
    [super dealloc];
}


@end
